<?php
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);

$nombre = trim($data['name'] ?? '');
$email = trim($data['email'] ?? '');
$password = $data['password'] ?? '';
$phone = trim($data['phone'] ?? ''); // aunque no lo uses en BD, lo puedes eliminar
$userType = trim($data['userType'] ?? '');

if (!$nombre || !$email || !$password || !$userType) {
    echo json_encode(['success' => false, 'message' => 'Faltan campos obligatorios']);
    exit;
}

// Aquí deberías validar email, etc. (omito por brevedad)

// Hash de contraseña para seguridad
$pass_hash = password_hash($password, PASSWORD_DEFAULT);

$conn = new mysqli('localhost', 'root', '', 'productosdb');

if ($conn->connect_error) {
    echo json_encode(['success' => false, 'message' => 'Error de conexión a la base de datos']);
    exit;
}

// Comprobar si email ya existe
$stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    echo json_encode(['success' => false, 'message' => 'El correo ya está registrado']);
    $stmt->close();
    $conn->close();
    exit;
}

$stmt->close();

// Insertar usuario en tabla (sin teléfono si no lo tienes en DB)
$stmt = $conn->prepare("INSERT INTO usuarios (nombre, email, password, tipo_usuario) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $nombre, $email, $pass_hash, $userType);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Usuario registrado correctamente']);
} else {
    echo json_encode(['success' => false, 'message' => 'Error al insertar usuario']);
}

$stmt->close();
$conn->close();
?>
