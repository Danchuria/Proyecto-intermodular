<?php
// login.php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=utf-8");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

try {
    $pdo = new PDO("mysql:host=localhost;dbname=productosdb;charset=utf8", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $inputJSON = file_get_contents("php://input");
    $data = json_decode($inputJSON, true);

    if (!$data) {
        echo json_encode([
            "success" => false,
            "message" => "❌ No llegaron datos válidos"
        ]);
        exit;
    }

    if (empty($data["Email"]) || empty($data["Password"])) {
        echo json_encode([
            "success" => false,
            "message" => "❌ Faltan campos obligatorios"
        ]);
        exit;
    }

    $stmt = $pdo->prepare("SELECT Email, Nombre, Password, NumeroTelefono FROM User WHERE Email = ?");
    $stmt->execute([$data["Email"]]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        echo json_encode([
            "success" => false,
            "message" => "⚠️ Usuario no encontrado"
        ]);
        exit;
    }

    if (!password_verify($data["Password"], $user["Password"])) {
        echo json_encode([
            "success" => false,
            "message" => "⚠️ Contraseña incorrecta"
        ]);
        exit;
    }

    echo json_encode([
        "success" => true,
        "message" => "✅ Login exitoso",
        "user" => [
            "Email" => $user["Email"],
            "Nombre" => $user["Nombre"],
            "NumeroTelefono" => $user["NumeroTelefono"]
        ]
    ]);

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "💥 Error interno del servidor",
        "error" => $e->getMessage()
    ]);
}

