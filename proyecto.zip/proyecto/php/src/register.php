<?php
// register.php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=utf-8");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

try {
    // Conexión a la base de datos
    $pdo = new PDO("mysql:host=localhost;dbname=productosdb;charset=utf8", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $inputJSON = file_get_contents("php://input");
    $data = json_decode($inputJSON, true);

    if (!$data) {
        echo json_encode([
            "success" => false,
            "message" => "❌ No llegaron datos válidos"
        ]);
        exit;
    }

    if (
        empty($data["Email"]) ||
        empty($data["Nombre"]) ||
        empty($data["Password"]) ||
        empty($data["NumeroTelefono"])
    ) {
        echo json_encode([
            "success" => false,
            "message" => "❌ Faltan campos obligatorios"
        ]);
        exit;
    }

    // Verificar si email ya existe
    $stmt = $pdo->prepare("SELECT Email FROM User WHERE Email = ?");
    $stmt->execute([$data["Email"]]);
    if ($stmt->fetch()) {
        echo json_encode([
            "success" => false,
            "message" => "⚠️ Este correo ya está registrado"
        ]);
        exit;
    }

    $passwordHash = password_hash($data["Password"], PASSWORD_DEFAULT);

    // Insertar usuario
    $stmt = $pdo->prepare("INSERT INTO User (Email, Nombre, Password, NumeroTelefono) VALUES (?, ?, ?, ?)");
    $result = $stmt->execute([$data["Email"], $data["Nombre"], $passwordHash, $data["NumeroTelefono"]]);

    if ($result) {
        echo json_encode([
            "success" => true,
            "message" => "✅ Usuario registrado correctamente"
        ]);
    } else {
        echo json_encode([
            "success" => false,
            "message" => "⚠️ Error al insertar en la base de datos"
        ]);
    }

} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        "success" => false,
        "message" => "💥 Error interno del servidor",
        "error" => $e->getMessage()
    ]);
}
